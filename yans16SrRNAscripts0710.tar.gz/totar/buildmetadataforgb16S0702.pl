#!/usr/bin/env perl
use warnings;
#This script built a metadata table for ancombc from the original qiime import manifest file.
open (INP, "< $ARGV[0]"); #picrustcodeswithtimepoints.txt
open (OUT, "> $ARGV[1]");
print OUT "ID\tbiotype\thost_species\thost_cultivar\ttimepoint\tsusceptibility\n";
while ($line = <INP>) {
  chomp $line;
  #16sP2_B8_EW1    E       W       W1      0       1
  @vars = split(/\t/, $line);
  if ($vars[2] eq "W") {$hostspecies = "wheat";}
  elsif ($vars[2] eq "B") {$hostspecies = "barley";}
  elsif ($vars[2] eq "A") {$hostspecies = "Aegilops_triuncialis";}
  elsif ($vars[2] eq "R") {$hostspecies = "rye";}
  elsif ($vars[2] eq "S") {$hostspecies = "sorghum";}
  else {$hostspecies = "other";}
  if ($vars[3] eq "A1") {$hostcultivar = "TA1675";}
  elsif ($vars[3] eq "A2") {$hostcultivar = "TA1695";}
  elsif ($vars[3] eq "B1") {$hostcultivar = "Wintermalt";}
  elsif ($vars[3] eq "B2") {$hostcultivar = "Jao";}
  elsif ($vars[3] eq "B3") {$hostcultivar = "Post_90";}
  elsif ($vars[3] eq "R1") {$hostcultivar = "Elbo";}
  elsif ($vars[3] eq "R2") {$hostcultivar = "Insave";}
  elsif ($vars[3] eq "S1") {$hostcultivar = "TX7000";}
  elsif ($vars[3] eq "S2") {$hostcultivar = "TX2737";}
  elsif ($vars[3] eq "S3") {$hostcultivar = "TX2783";}
  elsif ($vars[3] eq "S4") {$hostcultivar = "PI550607";}
  elsif ($vars[3] eq "W1") {$hostcultivar = "Newton";}
  elsif ($vars[3] eq "W2") {$hostcultivar = "Custer";}
  elsif ($vars[3] eq "W3") {$hostcultivar = "Amigo";}
  elsif ($vars[3] eq "W4") {$hostcultivar = "Largo";}
  elsif ($vars[3] eq "W5") {$hostcultivar = "C117882";}
  elsif ($vars[3] eq "W6") {$hostcultivar = "GRS_1201";}
  else {$hostcultivar = "other";}
  if ($vars[4] == 0) {$timepoint = 0;}
  elsif ($vars[4] == 1) {$timepoint = 2;}
  elsif ($vars[4] == 2) {$timepoint = 4;}
  elsif ($vars[4] == 3) {$timepoint = 8;}
  else {$timepoint = 10000;} #infinity
  if ($vars[3] eq "A1") {$susceptibility = "not_tested";}
  elsif ($vars[3] eq "A2") {$susceptibility = "not_tested";}
  elsif ($vars[3] eq "B1") {$susceptibility = "susceptible";}
  elsif ($vars[3] eq "B2") {$susceptibility = "not_tested";}
  elsif ($vars[3] eq "B3") {$susceptibility = "resistant";}
  elsif ($vars[3] eq "R1") {$susceptibility = "susceptible";}
  elsif ($vars[3] eq "R2") {$susceptibility = "resistant";}
  elsif ($vars[3] eq "S1") {$susceptibility = "susceptible";}
  elsif ($vars[3] eq "S2") {$susceptibility = "susceptible";}
  elsif ($vars[3] eq "S3") {$susceptibility = "not_tested";}
  elsif ($vars[3] eq "S4") {$susceptibility = "not_tested";}
  elsif ($vars[3] eq "W1") {$susceptibility = "susceptible";}
  elsif ($vars[3] eq "W2") {$susceptibility = "susceptible";}
  elsif ($vars[3] eq "W3") {$susceptibility = "susceptible";}
  elsif ($vars[3] eq "W4") {$susceptibility = "resistant";}
  elsif ($vars[3] eq "W5") {$susceptibility = "resistant";}
  elsif ($vars[3] eq "W6") {$susceptibility = "resistant";}
  else {$susceptibility = "other";}
  print OUT "$vars[0]\t$vars[1]\t$hostspecies\t$hostcultivar\t$timepoint\t$susceptibility\n";
}
