#!/usr/bin/env perl
use warnings;
#This script output the difference between two input files.  It extracted Buchnera ASVs to use in PICRUSt2.
open (SEA, "< $ARGV[0]"); #/scratch/negishi/ycrane/qiime2ops062025/gbmultihostrepseqs.fasta
open (SEB, "< $ARGV[1]"); #/scratch/negishi/ycrane/qiime2ops062025/gbmultihostrepseqswithoutBuchnera.fasta
open (CNA, "< $ARGV[2]"); #/scratch/negishi/ycrane/qiime2ops062025/gbmultihost16Sfeaturesfrombiom.txt
open (CNB, "< $ARGV[3]"); #/scratch/negishi/ycrane/qiime2ops062025/gbmultihost16SfeatureswithoutBuchnera.txt
open (OUA, "> $ARGV[4]");
open (OUB, "> $ARGV[5]");
while ($line = <SEB>) {
  if ($line =~ m/>/) {
    chomp $line;
    ($name = $line) =~ s/>//;
    $dumpers{$name} = 1;
  }
}
$getflag = 0;
while ($line = <SEA>) {
  if ($line =~ m/>/) {
    ($name = $line) =~ s/>//;
    chomp $name;
    if (exists($dumpers{$name})) {$getflag = 0;}
    else {$getflag = 1;}
  }
  if ($getflag == 1) {print OUA $line;}
}
$line = <CNA>;
print OUB $line;
while ($line = <CNA>) {
  #e94f15ce6822e46e2f791b17d9c0249e        1422.0  1478.0 ...
  ($name, $stuff) = split(/\t/, $line, 2);
  if (!exists($dumpers{$name})) {print OUB $line;}
}
