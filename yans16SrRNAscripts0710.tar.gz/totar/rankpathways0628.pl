#!/usr/bin/env perl
use warnings;
#This script ranks PICRUSt2 pathways in two files for comparison.
open (INA, "< $ARGV[0]"); #/scratch/negishi/ycrane/qiime2ops062025/picrust2out/pathways_out/path_abun_unstrat.tsv
open (INB, "< $ARGV[1]"); #/scratch/negishi/ycrane/qiime2ops062025/secondpicrust2out/pathways_out/path_abun_unstrat.tsv
open (OUT, "> $ARGV[2]"); #picrust2rankedpathways16SwithandwithoutBuchnera.txt
$topn = $ARGV[3]; #30
$line = <INA>;
while ($line = <INA>) {
  chomp $line;
  @vars = split(/\t/, $line);
  #1CMET2-PWY      175234.81130975502      74007.90542899526   ...
  $sum = $vars[1];
  for ($i = 2; $i < scalar(@vars); $i++) {$sum += $vars[$i];}
  $sums{$vars[0]} = $sum;
}
$line = <INB>;
while ($line = <INB>) {
  chomp $line;
  @vars = split(/\t/, $line);
  #1CMET2-PWY      175234.81130975502      74007.90542899526   ...
  $secsum = $vars[1];
  for ($i = 2; $i < scalar(@vars); $i++) {$secsum += $vars[$i];}
  $secsums{$vars[0]} = $secsum;
}
for $key (sort {$sums{$b} <=> $sums{$a}} (keys(%sums))) {
  push (@sumnames, $key);
  push (@sumvalues, $sums{$key});
}
for $key (sort {$secsums{$b} <=> $secsums{$a}} (keys(%secsums))) {
  push (@secsumnames, $key);
  push (@secsumvalues, $secsums{$key});
}
for ($i = 0; $i < $topn; $i++) {print OUT "$sumnames[$i]\t$sumvalues[$i]\t$secsumnames[$i]\t$secsumvalues[$i]\n";}
