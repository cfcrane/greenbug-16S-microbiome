#!/usr/bin/env perl
use warnings;
#This script built a table of $N most significant log2 fold-changes, p-values, and adjusted p-values.
open (LFA, "< $ARGV[0]"); #/scratch/negishi/ycrane/qiime2ops062025/8516a7e0-d816-4f69-944c-15908f1a8d79/data/ordered_lfc_slice.csv
open (PVA, "< $ARGV[1]"); #/scratch/negishi/ycrane/qiime2ops062025/8516a7e0-d816-4f69-944c-15908f1a8d79/data/ordered_pval_slice.csv
open (QVA, "< $ARGV[2]"); #/scratch/negishi/ycrane/qiime2ops062025/8516a7e0-d816-4f69-944c-15908f1a8d79/data/ordered_qval_slice.csv
open (LFB, "< $ARGV[3]"); #/scratch/negishi/ycrane/qiime2ops062025/b2d275b4-a940-4784-967a-df8264224d92/data/ordered_lfc_slice.csv
open (PVB, "< $ARGV[4]");  #/scratch/negishi/ycrane/qiime2ops062025/b2d275b4-a940-4784-967a-df8264224d92/data/ordered_p_val_slice.csv
open (QVB, "< $ARGV[5]"); #/scratch/negishi/ycrane/qiime2ops062025/b2d275b4-a940-4784-967a-df8264224d92/data/ordered_q_val_slice.csv
open (OUT, "> $ARGV[6]");
$N = $ARGV[7]; #10
$line = <PVA>;
for ($i = 0; $i < $N; $i++) {
  $line = <PVA>;
  #Erwinia,0.14013474406939005,0.0020552460543879544
  chomp $line;
  @vars = split(/,/, $line);
  $pvavalues{$vars[0]} = $vars[2];
  push(@pvanames, $vars[0]);
}
$line = <LFA>;
while ($line = <LFA>) {
  chomp $line;
  @vars = split(/,/, $line);
  if (exists($pvavalues{$vars[0]})) {$lfavalues{$vars[0]} = $vars[2];}
}
$line = <QVA>;
while ($line = <QVA>) {
  chomp $line;
  @vars = split(/,/, $line);
  if (exists($pvavalues{$vars[0]})) {$qvavalues{$vars[0]} = $vars[2];}
}
$line = <PVB>;
while ($line = <PVB>) {
  chomp $line;
  @vars = split(/,/, $line);
  if (exists($pvavalues{$vars[0]})) {$pvbvalues{$vars[0]} = $vars[2];}
}
$line = <QVB>;
while ($line = <QVB>) {
  chomp $line;
  @vars = split(/,/, $line);
  if (exists($pvavalues{$vars[0]})) {$qvbvalues{$vars[0]} = $vars[2];}
}
$line = <LFB>;
while ($line = <LFB>) {
  chomp $line;
  @vars = split(/,/, $line);
  if (exists($pvavalues{$vars[0]})) {$lfbvalues{$vars[0]} = $vars[2];}
}
print OUT "genus\tlogfc\tp-value\tq-value\tlogfc\tp-value\tq-value\n";
for ($i = 0; $i < $N; $i++) {
  printf OUT "%s\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\n", $pvanames[$i], $lfavalues{$pvanames[$i]}, $pvavalues{$pvanames[$i]}, $qvavalues{$pvanames[$i]}, $lfbvalues{$pvanames[$i]}, $pvbvalues{$pvanames[$i]}, $qvbvalues{$pvanames[$i]};
}
