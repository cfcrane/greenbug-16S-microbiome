#!/usr/bin/env perl
use warnings;
#This script stripped out lines for the given taxon in gbmultihostfreqfeaturetable0706.txt.
open (TAX, "< $ARGV[0]"); #gbmultihosttaxonomy0706.txt
open (FRQ, "< $ARGV[1]"); #/scratch/negishi/ycrane/qiime2ops062025/gbmultihostfreqfeaturetable0706.txt
open (OUT, "> $ARGV[2]"); #/scratch/negishi/ycrane/qiime2ops062025/gbmultihostfreqfeaturetable0706minBuchnera.txt
$purgee = $ARGV[3]; #Buchnera
$line = <TAX>; #Skip the header.
while ($line = <TAX>) {
  chomp $line;
  @vars = split(/\t/, $line);
  #5afd3d5a55420e8c9447a1a03dca1abc        Buchnera
  if ($vars[1] eq $purgee) {$purgees{$vars[0]} = $purgee;}
}
$line = <FRQ>;
print OUT $line;
while ($line = <FRQ>) {
  ($name, $stuff) = split(/\t/, $line, 2);
  if (!exists($purgees{$name})) {print OUT $line;}
}
