#!/usr/bin/env perl
use warnings;
#This script added a "group" column to gbmultihostmetadatasubsetforancombc0702.txt.  This column grouped replicates.
open (INP, "< $ARGV[0]"); #gbmultihostmetadatasubsetforancombc0702.txt
open (OUT, "> $ARGV[1]");
$line = <INP>;
chomp $line;
print OUT "$line\tgroup\n";
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\t/, $line);
  #ID      biotype host_species    host_cultivar   timepoint       susceptibility  replicate
  #16sP1_A1_EW1    E       wheat   Newton  2       susceptible     1
  @tars = split(/_/, $vars[0]);
  $group = $tars[2]."_".$vars[4];
  print OUT "$line\t$group\n";
}
