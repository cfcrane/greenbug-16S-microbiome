#!/usr/bin/env perl
use warnings;
#This script identified differences in ASV names between gbmultihostforancombcfeaturetable16S.txt and gbmultihostrepseqsetprokarotictaxa.txt.
open (TAB, "< $ARGV[0]"); #/scratch/negishi/ycrane/qiime2ops062025/2e3b5750-7e5b-494e-bac5-8850a9464fdd/data/gbmultihostforancombcfeaturetable16S.txt
open (TAX, "< $ARGV[1]"); #gbmultihostrepseqsetprokarotictaxa.txt
open (OUT, "> $ARGV[2]");
$minlimit = $ARGV[3]; #400
$line = <TAB>; #Skip the header.
while ($line = <TAB>) {
  chomp $line;
  ($name, @vars) = split(/\t/, $line);
  $tablenames{$name} = 0;
  for ($i = 0; $i < scalar(@vars); $i++) {$tablenames{$name} += $vars[$i];}
}
$line = <TAX>; #Skip the header.
while ($line = <TAX>) {
  chomp $line;
  ($name, $taxon) = split(/\t/, $line);
  $taxaids{$name} = $taxon;
}
$intableonly = 0;
$intaxaonly = 0;
$inboth = 0;
print OUT "In both:\n";
for $key (keys(%tablenames)) {
  if (exists($taxaids{$key})) {$inboth++; print OUT "$key $tablenames{$key} $taxaids{$key}\n";}
  else {
    $intableonly++;
    $namesintableonly{$key} = $tablenames{$key};
    if ($tablenames{$key} > $minlimit) {$abundantintableonly{$key} = $tablenames{$key};}
  }
}
print OUT "In frequency table only:\n";
for $key (keys(%namesintableonly)) {print OUT "$key $namesintableonly{$key}\n";}
print OUT "In taxon list only:\n";
for $key (keys(%taxaids)) {
  if (!exists($tablenames{$key})) {$intaxaonly++; print OUT "$key $taxaids{$key}\n";}
}
for $key (keys(%abundantintableonly)) {print OUT "abundant but in table only: $key $abundantintableonly{$key}\n";}
print OUT "Total in both = $inboth total in table only = $intableonly total in taxa only = $intaxaonly\n";
