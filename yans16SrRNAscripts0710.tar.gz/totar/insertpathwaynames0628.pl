#!/usr/bin/env perl
use warnings;
#This script inserted spelled-out pathway names into xx.
open (INP, "< $ARGV[0]"); #picrust2rankedpathways16SwithandwithoutBuchnera.txt
open (MAP, "< $ARGV[1]"); #metacyc_pathways_info.txt
open (MAQ, "< $ARGV[2]"); #metacyc-pwy_name.txt
open (OUT, "> $ARGV[3]");
while ($line = <MAP>) {
  chomp $line;
  #PWY-3001	superpathway of L-isoleucine biosynthesis I
  ($name, $fullname) = split(/\t/, $line, 2);
  $mapnames{$name} = $fullname;
}
while ($line = <MAQ>) {
  chomp $line;
  #PWY-3001	superpathway of L-isoleucine biosynthesis I
  ($name, $fullname) = split(/\t/, $line, 2);
  $maqnames{$name} = $fullname;
}
$linecount = 0;
while ($line = <INP>) {
  chomp $line;
  #PWY-3001        33623938.2318236        PWY-7094        1993050.7948182
  @vars = split(/\t/, $line);
  if (exists($mapnames{$vars[0]})) {$firstname = $mapnames{$vars[0]};}
  elsif (exists($maqnames{$vars[0]})) {$firstname = $maqnames{$vars[0]};}
  else {$firstname = $vars[0];}
  $leftrank{$firstname} = $linecount;
  if (exists($mapnames{$vars[2]})) {$secondname = $mapnames{$vars[2]};}
  elsif (exists($maqnames{$vars[2]})) {$secondname = $maqnames{$vars[2]};}
  else {$secondname = $vars[2];}
  $rightrank{$secondname} = $linecount;
  printf OUT "%s\t%11.2f\t%s\t%11.2f\n", $firstname, $vars[1], $secondname, $vars[3];
  $linecount++;
}
$higherinleft = 0;
$higherinright = 0;
$undecidedheight = 0;
$equalheight = 0;
for $key (keys(%leftrank)) {
  if (!exists($rightrank{$key})) {$undecidedheight++;}
  elsif ($leftrank{$key} > $rightrank{$key}) {$higherinright++;} #Low index is higher rank, i.e., greater abundance.
  elsif ($leftrank{$key} < $rightrank{$key}) {$higherinleft++;}
  else {$equalheight++;}
}
for $key (keys(%rightrank)) {
  if (!exists($leftrank{$key})) {$undecidedheight++;}
}
print "Higher rank (lower index) in left = $higherinleft higher in right = $higherinright equal = $equalheight undefined on either side = $undecidedheight\n";
