#!/usr/bin/env perl
use warnings;
#This script collects a set of highly hit accessions in SLIVA SSU from a list of blast outputs.
open (LIS, "< $ARGV[0]"); #blastfiles07052025.txt
open (SEQ, "< $ARGV[1]"); #/scratch/negishi/ycrane/SILVA_138.2_SSUParc_tax_asDNA.fasta
open (OUT, "> $ARGV[2]");
$N = $ARGV[3]; #10
while ($file = <LIS>) {
  print "first opening $file";
  chomp $file;
  open (BLA, "< $file"); 
  $lastname = "NULL";
  while ($line = <BLA>) {
    ($name, $stuff) = split(/\t/, $line, 2);
    if ($name ne $lastname) {$counter = 0;}
    if ($counter < $N) {
      #d89f3f7e26fa228fcc8c389b26458055        414     415     374     2       2       2.88e-150       1       414     GBDP01054324.1.961      961     249     662
      chomp $line;
      @vars = split(/\t/, $line);
      if ($vars[7] == $vars[1]) {
        if (exists($hits{$vars[9]})) {$hits{$vars[9]}++;}
	else {$hits{$vars[9]} = 1;}
      }
      elsif ($vars[8] == $vars[1]) {
        if (exists($hits{$vars[9]})) {$hits{$vars[9]}++;}
	else {$hits{$vars[9]} = 1;}
      }
      else { #The ASV read is probably chimeric. Assign these to the genus of the longer subsequence.
	if (exists($partialhits{$vars[9]})) {$partialhits{$vars[9]}++;}
	else {$partialhits{$vars[9]} = 1;}
      }
    }
    $lastname = $name;
    $counter++;
  }
}
#for $key (sort(keys(%hits))) {print OUT "$key\t$hits{$key}\n";}
while ($line = <SEQ>) {
  if ($line =~ m/^>/) {
    #>AY864045.1.640 Bacteria;Cyanobacteriota;Cyanobacteriia;Chloroplast;Incertae Sedis;Incertae Sedis;Chattonella marina
    ($name, $stuff) = split(/ /, $line, 2);
    $name =~ s/>//;
    if (exists($hits{$name})) {
      chomp $stuff;
      @vars = split(/;/, $stuff);
      if ($vars[3] =~ m/Chloroplast/i) {$hitgenera{$name} = "chloroplast";}
      elsif ($vars[5] =~ m/incertae sedis/i) {$hitgenera{$name} = $vars[4]." incertae sedis";}
      else {$hitgenera{$name} = $vars[5];}
    }
    if (exists($partialhits{$name})) {
      chomp $stuff;
      @vars = split(/;/, $stuff);
      if ($vars[3] =~ m/chloroplast/i) {$partiallyhitgenera{$name} = "chloroplast";}
      elsif ($vars[5] =~ m/incertae sedis/i) {$partiallyhitgenera{$name} = $vars[4]." incertae sedis";}
      else {$partiallyhitgenera{$name} = $vars[5];}
    }
  }
}
seek(LIS, 0, 0);
while ($file = <LIS>) {
  print "second opening $file";
  chomp $file;
  open (BLA, "< $file");
  $lastname = "NULL";
  while ($line = <BLA>) {
    ($name, $stuff) = split(/\t/, $line, 2);
    if ($name ne $lastname) {$counter = 0; $foundgenera{$name} = "unidentified";}
    if ($counter < $N) {
      chomp $line;
      @vars = split(/\t/, $line);
      if (exists($hitgenera{$vars[9]})) {
        $foundgenera{$name} = $hitgenera{$vars[9]};
       	$counter = $counter + $N + 1;
      }
      elsif (exists($partiallyhitgenera{$vars[9]})) {
  	$foundgenera{$name} = $partiallyhitgenera{$vars[9]}; #Use the genus that most of the chimera hit.
       	$counter = $counter + $N + 1;
      }
    }
    $lastname = $name;
    $counter++;
  }
}
for $key (sort {$foundgenera{$a} cmp $foundgenera{$b}} (keys(%foundgenera))) {
  print OUT "$key\t$foundgenera{$key}\n";
}
