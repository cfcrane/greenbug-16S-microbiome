#!/usr/bin/env perl
use warnings;
#This script calculated a distance matrix from /scratch/negishi/ycrane/qiime2ops062025/picrust2out/pathways_out/path_abun_unstrat.tsv .
open (INP, "< $ARGV[0]"); #/scratch/negishi/ycrane/qiime2ops062025/picrust2out/pathways_out/path_abun_unstrat.tsv
open (COD, "< $ARGV[1]"); #picrustcodeswithtimepoints.txt
open (OUT, "> $ARGV[2]");
while ($line = <COD>) {
  chomp $line;
  #16sP1_B9_ES3    E       S       S3      1       2
  ($name, @vars) = split(/\t/, $line);
  $dates{$name} = $vars[3];
}
$line = <INP>;
chomp $line;
($filler, @fields) = split(/\t/, $line);
printf "%d\n", scalar(@fields);
for ($i = 0; $i < scalar(@fields); $i++) {
  #16sP2_E10_KA2
  @tars = split(/_|\-/, $fields[$i]);
  $codes{$fields[$i]} = $tars[0]."_".$tars[2]."_".$dates{$fields[$i]};
  if (exists($occurrences{$tars[-1]})) {$occurrences{$tars[-1]}++;}
  else {$occurrences{$tars[-1]} = 1;}
  if ($tars[-1] eq "KA2") {print "$fields[$i]\n";}
}
for $key (sort {$codes{$a} cmp $codes{$b}} (keys(%codes))) {
  #print OUT "$key\t$codes{$key}\n";
  if (exists($codelist{$codes{$key}})) {$codelist{$codes{$key}}++;}
  else {$codelist{$codes{$key}} = 1;}
}
$ntreatments = scalar(%occurrences);
print "There were $ntreatments treatments.\n";
#for $key (sort(keys(%occurrences))) {print OUT "$key\t$occurrences{$key}\n";}
while ($line = <INP>) {
  chomp $line;
  ($func, @vars) = split(/\t/, $line);
  for ($i = 0; $i < scalar(@vars); $i++) {
    if (exists($functionsums{$codes{$fields[$i]}}{$func})) {$functionsums{$codes{$fields[$i]}}{$func} += $vars[$i];}
    else {$functionsums{$codes{$fields[$i]}}{$func} = $vars[$i];}
  }
}
for $key (keys(%codelist)) {$codesums{$key} = 0;}
for $key (sort(keys(%functionsums))) {
  for $index (sort(keys(%{$functionsums{$key}}))) {
    #print OUT "$key\t$index\t$functionsums{$key}{$index}\n";
    $codesums{$key} += $functionsums{$key}{$index};
  }
}
#for $key (sort(keys(%codesums))) {print OUT "$key sum = $codesums{$key}\n";}
for $key (keys(%functionsums)) {
  if ($codesums{$key} > 0) {
    for $index (keys(%{$functionsums{$key}})) {$functionfracs{$key}{$index} = 100 * $functionsums{$key}{$index} / $codesums{$key};}
  }
  else {$functionfracs{$key}{$index} = 0;}
}
for $key (sort(keys(%functionfracs))) {
  #for $index (sort(keys(%{$functionfracs{$key}}))) {print OUT "frac $key $index = $functionfracs{$key}{$index}\n";}
}
for $keya (sort(keys(%functionfracs))) {
  for $keyb (sort(keys(%functionfracs))) {
    $dist{$keya}{$keyb} = 0;
    for $index (sort(keys(%{$functionfracs{$keya}}))) {
      $dist{$keya}{$keyb} += ($functionfracs{$keya}{$index} - $functionfracs{$keyb}{$index})**2;
    }
  }
}
for $key (sort(keys(%dist))) {print OUT "\t$key";}
print OUT "\n";
for $keya (sort(keys(%dist))) {
  print OUT $keya;
  for $keyb (sort(keys(%dist))) {print OUT "\t$dist{$keya}{$keyb}";}
  print OUT "\n";
}
