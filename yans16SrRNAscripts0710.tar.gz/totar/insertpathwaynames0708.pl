#!/usr/bin/env perl
use warnings;
#This script inserted spelled-out pathway names into picrust2rankedpathways16SwithwithoutandfromBuchnera.txt.
open (INP, "< $ARGV[0]"); #picrust2rankedpathways16SwithwithoutandfromBuchnera.txt
open (MAP, "< $ARGV[1]"); #metacyc_pathways_info.txt
open (MAQ, "< $ARGV[2]"); #metacyc-pwy_name.txt
open (OUT, "> $ARGV[3]");
while ($line = <MAP>) {
  chomp $line;
  #PWY-3001	superpathway of L-isoleucine biosynthesis I
  ($name, $fullname) = split(/\t/, $line, 2);
  $mapnames{$name} = $fullname;
}
while ($line = <MAQ>) {
  chomp $line;
  #PWY-3001	superpathway of L-isoleucine biosynthesis I
  ($name, $fullname) = split(/\t/, $line, 2);
  $maqnames{$name} = $fullname;
}
$linecount = 0;
while ($line = <INP>) {
  chomp $line;
  #PWY-3001        33623938.2318236        PWY-7094        1993050.7948182
  @vars = split(/\t/, $line);
  if (exists($mapnames{$vars[0]})) {$firstname = $mapnames{$vars[0]};}
  elsif (exists($maqnames{$vars[0]})) {$firstname = $maqnames{$vars[0]};}
  else {$firstname = $vars[0];}
  $leftrank{$firstname} = $linecount;
  if (exists($mapnames{$vars[2]})) {$secondname = $mapnames{$vars[2]};}
  elsif (exists($maqnames{$vars[2]})) {$secondname = $maqnames{$vars[2]};}
  else {$secondname = $vars[2];}
  $midrank{$secondname} = $linecount;
  if (exists($mapnames{$vars[4]})) {$thirdname = $mapnames{$vars[4]};}
  elsif (exists($maqnames{$vars[4]})) {$thirdname = $maqnames{$vars[4]};}
  else {$thirdname = $vars[4];}
  $rightrank{$thirdname} = $linecount;
  printf OUT "%s\t%12.2f\t%s\t%12.2f\t%s\t%12.2f\n", $firstname, $vars[1], $secondname, $vars[3], $thirdname, $vars[5];
  $linecount++;
}
$higherinmid = 0;
$higherinright = 0;
$undecidedheight = 0;
$equalheight = 0;
for $key (keys(%rightrank)) {
  if (!exists($midrank{$key})) {$undecidedheight++;}
  elsif ($rightrank{$key} < $midrank{$key}) {$higherinright++;} #Low index is higher rank, i.e., greater abundance.
  elsif ($rightrank{$key} > $midrank{$key}) {$higherinmid++;}
  else {$equalheight++;}
}
for $key (keys(%midrank)) {
  if (!exists($rightrank{$key})) {$undecidedheight++;}
}
print "Higher rank (lower index) in mid = $higherinmid higher in right = $higherinright equal = $equalheight undefined on either side = $undecidedheight\n";
