#!/usr/bin/env perl
use warnings;
#This script built a table of aphid count and read counts for the 16S paper.
open (INP, "< $ARGV[0]"); #slurm-24812097.out
open (TAB, "< $ARGV[1]"); #GBcounts.txt
open (OUT, "> $ARGV[2]");
while ($line = <INP>) {
  chomp $line;
  ($linecount, $name) = split(/\s+/, $line);
  #2777296 /scratch/negishi/ycrane/gbmicrobiomeII/reads16s/7085-16sP1_A2_EW2-11-MS799F_S44_R1_001.fastq
  @tars = split(/\//, $name);
  @sars = split(/_|\-/, $tars[-1]);
  $code = $sars[3]."-".$sars[4];
  #print OUT "$code\t$name\n";
  $linecounts{$code} = $linecount / 4;
}
$line = <TAB>; #Skip the header.
while ($line = <TAB>) {
  if ($line =~ m/\w+/) {
    chomp $line;
    #ES4-33  Sorghum DZhugara Belaya (PI 550607)     96hr    10
    @vars = split(/\t/, $line);
    $species = $vars[1];
    $cultivar = $vars[2];
    $count = $vars[4];
    if ($vars[3] eq "24hr") {$date = 2;}
    elsif ($vars[3] eq "48hr") {$date = 4;}
    elsif ($vars[3] eq "96hr") {$date = 8;}
    else {$date = -1;}
    $outstrings{$vars[0]} = sprintf("%s\t%s\t%d\t%d", $species, $cultivar, $date, $count);
  }
}
$failures = 0;
for $key (sort(keys(%outstrings))) {
  if (exists($linecounts{$key})) {print OUT "$outstrings{$key}\t$linecounts{$key}\n";}
  else {print OUT "$outstrings{$key}\t0\n"; $failures++;}
}
print "Library preparation failed for $failures combinations of host, timepoint, and replicate.\n";
