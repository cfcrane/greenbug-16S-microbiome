#!/usr/bin/env perl 
use warnings;
#This script added a replicate column to gbmultihostmetadatasubsetforancombc0702.txt.
open (INP, "< $ARGV[0]"); #gbmultihostmetadatasubsetforancombc0702.txt
open (OUT, "> $ARGV[1]");
$line = <INP>;
chomp $line;
print OUT "$line\treplicate\n";
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\t/, $line);
  #16sP2_C8_EW1	E	wheat	Newton	0	susceptible
  if (exists($replicates{$vars[1]}{$vars[3]}{$vars[4]})) {$replicates{$vars[1]}{$vars[3]}{$vars[4]}++;}
  else {$replicates{$vars[1]}{$vars[3]}{$vars[4]} = 1;}
  print OUT "$line\t$replicates{$vars[1]}{$vars[3]}{$vars[4]}\n";
}
