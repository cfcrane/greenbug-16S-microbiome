#!/usr/bin/env perl
use warnings;
#This script prepared fasta and taxonomy files from SILVA_138.2_SSUParc_tax_silva.fasta.
#This script output only bacterial and archaeal sequences.
open (SEQ, "< $ARGV[0]"); #/scratch/negishi/ycrane/SILVA_138.2_SSUParc_tax_silva.fasta
open (TAX, "> $ARGV[1]"); #/scratch/negishi/ycrane/SILVA_138.2_taxonlist.txt
open (DAT, "> $ARGV[2]"); #/scratch/negishi/ycrane/SILVA_138.2_SSUParc_tax_asDNA.fasta
print TAX "Feature ID\tTaxon\n";
$printflag = 0;
while ($line = <SEQ>) {
  #>AB000393.1.1510 Bacteria;Pseudomonadota;Gammaproteobacteria;Enterobacterales;Vibrionaceae;Vibrio;Vibrio halioticoli
  if ($line =~ m/^>/) {
    if ($line =~ m/Bacteria/ || $line =~ m/Archaea/) {$printflag = 1;}
    else {$printflag = 0;}
  }
  if ($printflag == 1) {
    if ($line =~ m/>/) {
      ($name, $taxstring) = split (/\s+/, $line, 2);
      $name =~ s/>//;
      chomp $taxstring;
      @vars = split(/\;/, $taxstring);
      print TAX "$name\tk__$vars[0]; p__$vars[1]; c__$vars[2]; o__$vars[3]; f__$vars[4]; g__$vars[5]; s__$vars[6]\n";
      print DAT $line;
    }
    else {
      $line =~ s/U/T/g;
      $line =~ s/u/t/g;
      print DAT $line;
    }
  }
}
