#!/usr/bin/env perl
use warnings;
#This script acted on 
open (INP, "< $ARGV[0]"); #gbmultihostfrequencytaxadifference.txt
open (SEQ, "< $ARGV[1]"); #/scratch/negishi/ycrane/qiime2ops062025/fabdcda4-d16e-4f3d-ac13-a890432d187b/data/dna-sequences.fasta
open (SSQ, "> $ARGV[2]");
$ssqsearchstring = $ARGV[3]; #abundant
$ssqsearchfield = $ARGV[4]; #5
while ($line = <INP>) {
  if ($line =~ m/$ssqsearchstring/) {
    chomp $line;
    #abundant but in table only: 14062f61a101a431dbe56c98cf4d4992 1592
    @vars = split(/\s+/, $line);
    $minednames{$vars[$ssqsearchfield]} = 1;
  }
}
$getflag = 0;
while ($line = <SEQ>) {
  if ($line =~ m/>/) {
    #>e61eb56c9ba34c06c17b6c3471bfef4a
    ($name = $line) =~ s/>//;
    chomp $name;
    if (exists($minednames{$name})) {$getflag = 1;}
    else {$getflag = 0;}
  }
  if ($getflag == 1) {print SSQ $line;}
}
