#!/usr/bin/env perl
use warnings;
#This script set up blast jobs of representative sequences against SILVA.
open (SEQ, "< $ARGV[0]"); #/scratch/negishi/ycrane/qiime2ops062025/gbmultihostrepseqs.fasta
$database = $ARGV[1]; #/scratch/negishi/ycrane/SILVA_138.2_SSUParc_tax_silvadb
$jobstem = $ARGV[2]; #runblast06272025_
$querystem = $ARGV[3]; #/scratch/negishi/ycrane/qiime2ops062025/gbmultihostrepseqsset_
$blastoutstem = $ARGV[4]; #/scratch/negishi/ycrane/qiime2ops062025/gbmultihostrepseqsset_vs_SILVA_138_
$evalue = $ARGV[5]; #1e-20
$N = $ARGV[6]; #1120
$nprocs = $ARGV[7]; #4
$k = 0;
$seqcount = -1;
while ($line = <SEQ>) {
  if ($line =~ m/>/) {
    $seqcount++;
    if ($seqcount % $N == 0) {
      $queryfile = $querystem.$k.".fasta";
      push(@queryfiles, $queryfile);
      open (OUT, "> $queryfile");
      $k++;
    }
  }
  print OUT $line;
}
for ($i = 0; $i < $k; $i++) {
  $job = $jobstem.$i.".sh";
  open (JOB, "> $job");
  print JOB "#!/bin/bash\nsource /etc/profile\nml biocontainers blast\n";
  $blastoutfile = $blastoutstem.$i."_$evalue".".txt";
  print JOB "blastn -query $queryfiles[$i] -db $database -out $blastoutfile -evalue $evalue -num_threads $nprocs -outfmt \"6 qseqid qlen length nident gapopen gaps evalue qstart qend sseqid slen sstart send\"\n";
}
