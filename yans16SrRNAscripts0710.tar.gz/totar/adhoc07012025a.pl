#!/usr/bin/env perl
use warnings;
#This script identified and ranked functions limited to Buchnera or to other organisms.
open (INP, "< $ARGV[0]"); #picrust2all16SpathwayswithnameswithandwithoutBuchnera.txt
open (OUT, "> $ARGV[1]");
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\t/, $line);
  $leftvars{$vars[0]} = $vars[1];
  $rightvars{$vars[2]} = $vars[3];
}
for $key (keys(%leftvars)) {
  if (!exists($rightvars{$key})) {$onlyinlefts{$key} = $leftvars{$key};}
}
for $key (keys(%rightvars)) {
  if (!exists($leftvars{$key})) {$onlyinrights{$key} = $rightvars{$key};}
}
print OUT "Functions only in left column with Buchnera:\n";
for $key (sort {$onlyinlefts{$b} <=> $onlyinlefts{$a}} (keys(%onlyinlefts))) {
  print OUT "$key\t$onlyinlefts{$key}\n";
}
print OUT "Functions only in right column without Buchnera:\n";
for $key (sort {$onlyinrights{$b} <=> $onlyinrights{$a}} (keys(%onlyinrights))) {
  print OUT "$key\t$onlyinrights{$key}\n";
}
