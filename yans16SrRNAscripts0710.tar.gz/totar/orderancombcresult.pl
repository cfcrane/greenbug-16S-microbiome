#!/usr/bin/env perl
use warnings;
#This script orders a comma-delimited list by the numerical value in its column $N.
open (INP, "< $ARGV[0]"); #/scratch/negishi/ycrane/qiime2ops062025/8516a7e0-d816-4f69-944c-15908f1a8d79/data/lfc_slice.csv
open (OUT, "> $ARGV[1]");
$N = $ARGV[2]; #2
$line = <INP>;
print OUT $line;
while ($line = <INP>) {
  chomp $line;
  @vars = split(/,/, $line);
  $values{$vars[0]} = $vars[$N];
  $lines{$vars[0]} = $line;
}
for $key (sort {$values{$a} <=> $values{$b}} (keys(%values))) {print OUT "$lines{$key}\n";}
