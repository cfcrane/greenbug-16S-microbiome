#!/usr/bin/env perl
use warnings;
#This script subsets an existing qiime2 manifest file.
open (MAN, "< $ARGV[0]"); #qiime2manifestfor16S.txt
open (MET, "< $ARGV[1]"); #gbmultihostmetadataforancombc0702.txt
open (OUA, "> $ARGV[2]"); #qiime2manifest16Sforancombc0702.txt
open (OUB, "> $ARGV[3]"); #gbmultihostmetadatasubsetforancombc0702.txt
($codestring = $ARGV[4]) =~ s/\"//g; #"W1 W2 W3 W4 W5 W6 S1 S2 B1 B3 R1 R2"
@codes = split(/\s+/, $codestring);
$line = <MAN>;
print OUA $line;
while ($line = <MAN>) {
  #16sP1_A5_EW5    /scratch/negishi/ycrane/gbmicrobiomeII/reads16s/7085-16sP1_A5-EW5-11-MS799F_S68_R1_001.fastq    /scratch/negishi/ycrane/gbmicrobiomeII/reads16s/7085-16sP1_A5-EW5-11-MS799F_S68_R2_001.fastq
  ($code, $stuff) = split(/\t/, $line, 2);
  @bars = split(/_/, $code);
  $found = 0;
  for ($i = 0; $i < scalar(@codes); $i++) {
    if ($bars[2] =~ m/$codes[$i]/) {print OUA $line; last;}
  }
}
$line = <MET>;
print OUB $line;
while ($line = <MET>) {
  #16sP1_B5_EW5    E       wheat   C117882 2       resistant
  ($code, $stuff) = split(/\s+/, $line, 2);
  @bars = split(/_/, $code);
  $found = 0;
  for ($i = 0; $i < scalar(@codes); $i++) {
    if ($bars[2] =~ m/$codes[$i]/) {print OUB $line; last;}
  }
}
