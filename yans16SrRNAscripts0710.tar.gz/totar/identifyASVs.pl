#!/usr/bin/env perl
use warnings;
#This script attached taxonomic identity to tabular blast output.
open (SEQ, "< $ARGV[0]"); #/scratch/negishi/ycrane/SILVA_138.2_SSUParc_tax_silva.fasta
open (LIS, "< $ARGV[1]"); #blastoutfiles0627.txt
open (FNA, "< $ARGV[2]"); #/scratch/negishi/ycrane/qiime2ops062025/gbmultihostrepseqs.fasta
open (BIM, "< $ARGV[3]"); #/scratch/negishi/ycrane/qiime2ops062025/gbmultihost16Sfeaturesfrombiom.txt
open (OUA, "> $ARGV[4]"); #/scratch/negishi/ycrane/qiime2ops062025/gbmultihostrepseqswithoutBuchnera.fasta
open (OUB, "> $ARGV[5]"); #/scratch/negishi/ycrane/qiime2ops062025/gbmultihost16SfeatureswithoutBuchnera.txt
$targetgenus = $ARGV[6]; #Buchnera
while ($line = <SEQ>) {
  if ($line =~ m/>/) {
    chomp $line;
    #>KC058517.1.440 Bacteria;Pseudomonadota;Gammaproteobacteria;Enterobacterales;Morganellaceae;Arsenophonus;uncultured bacterium
    $line =~ s/>//;
    ($accession, $taxstring) = split(/\s+/, $line, 2);
    @vars = split(/\;/, $taxstring);
    $genera{$accession} = $vars[5];
    #print OUA "diag: accession = $accession genera{$accession} = $genera{$accession}\n";
  }
}
$lastread = "null";
while ($file = <LIS>) {
  chomp $file;
  open (BLA, "< $file");
  while ($line = <BLA>) {
    chomp $line;
    #3804388651abdbb1a000dd393b0a4029        411     417     383     6       9       7.84e-161       1       411     MKXH02000203.360214.361742      1529    777     1190
    @vars = split(/\t/, $line);
    #print OUA "$line\t$genera{$vars[9]}\n";
    if ($vars[0] ne $lastread) {
      $readstogenera{$vars[0]} = $genera{$vars[9]};
      $lastread = $vars[0];
    }
  }
}
$printflag = 0;
while ($line = <FNA>) {
  if ($line =~ m/>/) {
    #>8b54d984f8b778ead5343c3b5c4720f8
    ($readid = $line) =~ s/>//;
    chomp $readid;
    #die "readid = $readid from line = $line";
    if ($readstogenera{$readid} eq $targetgenus) {$printflag = 0;}
    else {$printflag = 1;}
  }
  if ($printflag == 1) {print OUA $line;}
}
$printflag = 0;
while ($line = <BIM>) {
  #8b54d984f8b778ead5343c3b5c4720f8        264486.0        218406.0 ...
  if ($line =~ m/\t\d+/) {
    ($name, $stuff) = split(/\t/, $line, 2);
    if (exists($readstogenera{$name})) {
      if ($readstogenera{$name} eq $targetgenus) {$printflag = 0;}
      else {$printflag = 1;}
    }
    else {$printflag = 1;}
  }
  else {$printflag = 1;}
  if ($printflag == 1) {print OUB $line;}
}
