#!/usr/bin/env perl
use warnings;
#This script reconciled the second input file to match entries in the first input file.
open (INA, "< $ARGV[0]"); #gbmultihosttaxonomy0706.txt
open (INB, "< $ARGV[1]"); #/scratch/negishi/ycrane/qiime2ops062025/2e3b5750-7e5b-494e-bac5-8850a9464fdd/data/gbmultihostforancombcfeaturetable16S.txt
open (OUT, "> $ARGV[2]");
$line = <INA>; #Skip the header.
while ($line = <INA>) {
  #c661c4f90c9ac601aa000d03a6bd5805        Buchnera
  ($name, $genus) = split(/\t/, $line);
  $usednames{$name} = 1;
}
$line = <INB>;
print OUT $line;
while ($line = <INB>) {
  #8b54d984f8b778ead5343c3b5c4720f8        217722.0 ...
  ($name, $stuff) = split(/\t/, $line, 2);
  if (exists($usednames{$name})) {print OUT $line;}
}
