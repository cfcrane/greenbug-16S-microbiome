#!/usr/bin/env perl
use warnings;
#This script prepared a manifest file for qiime tools import.
open (LIS, "< $ARGV[0]"); #filelist06202025a.txt
open (OUT, "> $ARGV[1]");
while ($file = <LIS>) {
  chomp $file;
  ($r2file = $file) =~ s/_R1_/_R2_/;
  if (-e $r2file) {
    @vars = split(/\-/, $file);
    print OUT "$vars[1]\t$file\t$r2file\n";
  }
  else {print "$r2file does not exist.\n";}
}
